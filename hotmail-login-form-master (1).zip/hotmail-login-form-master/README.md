# hotmail-login-form
This is a clone of the hotmail login form frontend

## Things you need to get started
- run `git clone https://github.com/samuel200/hotmail-login-form.git`
- start using the clone
